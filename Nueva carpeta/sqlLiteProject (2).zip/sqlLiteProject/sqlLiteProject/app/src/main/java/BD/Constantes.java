package BD;

public class Constantes {
    public static final String NOMBRE_BD = "Reserva.bd";
    public static final int VERSION_BD = 1;
    public static final String TABLA_USURIO = "USUARIOS";
}
